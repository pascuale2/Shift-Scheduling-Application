package com.example.shiftschedule;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class landingPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing_page);
    }

    public void seeEmployees (View view){
        Intent intent = new Intent(landingPage.this, employeePage.class);
        startActivity(intent);
    }

    public void goBack (View view){
        finish();
    }
}